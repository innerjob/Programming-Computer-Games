import java.awt.*;
public class Line 
{
	private int x;
	private int y;
	private int x1;
	private int y1;
	
	Color color = Color.black;
	
	public Line(int x, int y, int x1, int y1)
	{
		this.x = x;
		this.x1 = x1;
		this.y = y;
		this.y1 = y1;
	}
}
